package com.example.demo.Domain.Security.Auth;

public record CreateUserDTO(String name, String password, String email) {
}
