package com.example.demo.Domain.Security.Model;

public enum Role {
    ADMIN,
    USER
}
